package com.example.pisotab

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.app.AlertDialog
import android.app.DownloadManager
import android.media.AudioManager
import android.app.role.RoleManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.DocumentsContract
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.os.UserManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebStorage
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private lateinit var txtEsp32: TextView
    private lateinit var txtRate: TextView
    private lateinit var browserPanel: LinearLayout
    private lateinit var mainPanel: LinearLayout
    private lateinit var webView: WebView
    private lateinit var filePanel: LinearLayout
    private lateinit var fileList: LinearLayout
    private lateinit var txtBrowserTime: TextView
    private lateinit var remoteLockOverlay: LinearLayout
    private lateinit var txtRemoteLockMessage: TextView
    private lateinit var txtRemoteLockClient: TextView
    private lateinit var allowedAppsGrid: GridLayout
    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null
    private var socket: BluetoothSocket? = null

    private val prefs by lazy { getSharedPreferences("pisotab_settings", MODE_PRIVATE) }
    private var minutesPerPeso: Int
        get() = prefs.getInt("minutes_per_peso", 5)
        set(v) = prefs.edit().putInt("minutes_per_peso", v).apply()
    private var adminPassword: String
        get() = prefs.getString("admin_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("admin_password", v).apply()
    private var dialogRef: AlertDialog? = null
    private var staffPassword: String
        get() = prefs.getString("staff_password", "1234") ?: "1234"
        set(v) = prefs.edit().putString("staff_password", v).apply()
    private var kioskMode: Boolean
        get() = prefs.getBoolean("kiosk_mode", true)
        set(v) = prefs.edit().putBoolean("kiosk_mode", v).apply()
    private var defaultLauncher: Boolean
        get() = prefs.getBoolean("default_launcher", false)
        set(v) = prefs.edit().putBoolean("default_launcher", v).apply()
    private var bluetoothAlarm: Boolean
        get() = prefs.getBoolean("bt_alarm", false)
        set(v) = prefs.edit().putBoolean("bt_alarm", v).apply()
    private var chargerAlarm: Boolean
        get() = prefs.getBoolean("charger_alarm", false)
        set(v) = prefs.edit().putBoolean("charger_alarm", v).apply()
    private var whitelistMode: Boolean
        get() = prefs.getBoolean("whitelist_mode", true)
        set(v) = prefs.edit().putBoolean("whitelist_mode", v).apply()
    private val recommendedAllowedPackages = setOf(
        "com.android.chrome",
        "com.google.android.youtube",
        "com.google.android.apps.nbu.files",
        "com.google.android.apps.photos",
        "com.google.android.calculator"
    )
    private val maxAllowedApps = Int.MAX_VALUE
    private var allowedPackages: Set<String>
        get() = (prefs.getStringSet("allowed_packages", recommendedAllowedPackages) ?: recommendedAllowedPackages).toSet()
        set(v) = prefs.edit().putStringSet("allowed_packages", v.toSet()).apply()
    private var allowedFileExtensions: Set<String>
        get() = prefs.getStringSet("allowed_file_extensions", setOf("pdf", "jpg", "jpeg", "png", "mp4", "mp3", "txt")) ?: setOf("pdf", "jpg", "jpeg", "png", "mp4", "mp3", "txt")
        set(v) = prefs.edit().putStringSet("allowed_file_extensions", v.map { it.lowercase().removePrefix(".") }.toSet()).apply()
    private var allowedFolderUris: Set<String>
        get() = prefs.getStringSet("allowed_folder_uris", emptySet()) ?: emptySet()
        set(v) = prefs.edit().putStringSet("allowed_folder_uris", v).apply()
    private var currentFolderUri: Uri? = null
    private var activeCustomerPackage: String? = null
    private var btTargetName: String
        get() = prefs.getString("bt_target_name", "ESP32") ?: "ESP32"
        set(v) = prefs.edit().putString("bt_target_name", v).apply()
    private var autoClearOnExpiry: Boolean
        get() = prefs.getBoolean("auto_clear_on_expiry", true)
        set(v) = prefs.edit().putBoolean("auto_clear_on_expiry", v).apply()
    private var resetCustomerAppsOnSessionEnd: Boolean
        get() = prefs.getBoolean("reset_customer_apps_on_session_end", true)
        set(v) = prefs.edit().putBoolean("reset_customer_apps_on_session_end", v).apply()
    private var clientName: String
        get() = prefs.getString("client_name", "Client 01") ?: "Client 01"
        set(v) = prefs.edit().putString("client_name", v).apply()
    private var clientId: String
        get() = prefs.getString("client_id", "C001") ?: "C001"
        set(v) = prefs.edit().putString("client_id", v).apply()
    private var remoteControlEnabled: Boolean
        get() = prefs.getBoolean("remote_control_enabled", false)
        set(v) = prefs.edit().putBoolean("remote_control_enabled", v).apply()
    private var remoteControlUrl: String
        get() = prefs.getString("remote_control_url", "") ?: ""
        set(v) = prefs.edit().putString("remote_control_url", v).apply()
    private var remoteLocked: Boolean
        get() = prefs.getBoolean("remote_locked", false)
        set(v) = prefs.edit().putBoolean("remote_locked", v).apply()
    private var remoteLockMessage: String
        get() = prefs.getString("remote_lock_message", "This client is temporarily disabled by the administrator.") ?: "This client is temporarily disabled by the administrator."
        set(v) = prefs.edit().putString("remote_lock_message", v).apply()
    private var remotePollSeconds: Int
        get() = prefs.getInt("remote_poll_seconds", 15)
        set(v) = prefs.edit().putInt("remote_poll_seconds", v).apply()
    private var remoteThread: Thread? = null
    private var remoteRunning = false
    private var sessionLocked = false
    private var maxVolumePercent: Int
        get() = prefs.getInt("max_volume_percent", 50)
        set(v) = prefs.edit().putInt("max_volume_percent", v.coerceIn(0, 100)).apply()

    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        handleAccessBlockedIntent(intent)
        // Preselect common customer apps when the whitelist is used for the first time.
        if (!prefs.contains("allowed_packages")) {
            allowedPackages = recommendedAllowedPackages.toSet()
        }

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)
        txtEsp32 = findViewById(R.id.txtEsp32)
        txtRate = findViewById(R.id.txtRate)
        mainPanel = findViewById(R.id.mainPanel)
        browserPanel = findViewById(R.id.browserPanel)
        filePanel = findViewById(R.id.filePanel)
        fileList = findViewById(R.id.fileList)
        webView = findViewById(R.id.webView)
        txtBrowserTime = findViewById(R.id.txtBrowserTime)
        remoteLockOverlay = findViewById(R.id.remoteLockOverlay)
        txtRemoteLockMessage = findViewById(R.id.txtRemoteLockMessage)
        txtRemoteLockClient = findViewById(R.id.txtRemoteLockClient)
        allowedAppsGrid = findViewById(R.id.allowedAppsGrid)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener { addCoin() }
        findViewById<Button>(R.id.btnPisoTabHome).setOnClickListener {
            // Small launcher/home control: bring PisoTab itself back to the foreground.
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(launch)
            }
        }
        findViewById<Button>(R.id.btnBrowser).setOnClickListener { openBrowser() }
        findViewById<Button>(R.id.btnFiles).setOnClickListener { openFiles() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showPasswordDialog() }
        findViewById<Button>(R.id.btnMainHomeLauncher).setOnClickListener { goToHomeLauncher() }
        findViewById<Button>(R.id.btnBrowserHome).setOnClickListener { webView.loadUrl("file:///android_asset/home.html") }
        findViewById<Button>(R.id.btnBrowserBack).setOnClickListener { if (webView.canGoBack()) webView.goBack() else closeBrowser() }
        findViewById<Button>(R.id.btnFileBack).setOnClickListener { closeFiles() }
        findViewById<Button>(R.id.btnHomeLauncher).setOnClickListener { goToHomeLauncher() }
        findViewById<Button>(R.id.btnAdminUnlock).setOnClickListener { showUnlockDialog() }

        setupBrowser()
        updateScreen()
        requestBtPermission()
        applyVolumeLimit()
        persistSessionState()
        applyKioskMode()
        applyRemoteLockUi()
        startRemoteControl()
    }

    private fun setupBrowser() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            saveFormData = false
            setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_DEFAULT
            allowFileAccess = false
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val name = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .setTitle(name)
                    .setDescription("PisoTab customer download")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
                    .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) request.addRequestHeader("Cookie", cookies)
                request.addRequestHeader("User-Agent", userAgent)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun openBrowser() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        mainPanel.visibility = View.GONE
        browserPanel.visibility = View.VISIBLE
        if (webView.url.isNullOrBlank() || webView.url == "about:blank") webView.loadUrl("file:///android_asset/home.html")
        applyKioskMode()
    }

    private fun openFiles() {
        if (remoteLocked || sessionLocked) return
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        if (allowedFolderUris.isEmpty()) {
            Toast.makeText(this, "No folders allowed by Admin", Toast.LENGTH_LONG).show()
            return
        }
        mainPanel.visibility = View.GONE
        browserPanel.visibility = View.GONE
        filePanel.visibility = View.VISIBLE
        currentFolderUri = null
        showAllowedFolders()
    }

    private fun closeFiles() {
        filePanel.visibility = View.GONE
        mainPanel.visibility = View.VISIBLE
        currentFolderUri = null
    }

    private fun showAllowedFolders() {
        fileList.removeAllViews()
        val title = TextView(this).apply {
            text = "ALLOWED FILES"
            textSize = 24f
            setPadding(12, 12, 12, 12)
        }
        fileList.addView(title)
        allowedFolderUris.forEach { raw ->
            val uri = Uri.parse(raw)
            val name = uri.lastPathSegment?.substringAfterLast(":")?.replace('%', ' ') ?: "Allowed folder"
            val button = Button(this).apply {
                text = "📁 $name"
                setOnClickListener { browseFolder(uri) }
            }
            fileList.addView(button)
        }
    }

    private fun browseFolder(treeUri: Uri, documentUri: Uri = treeUri) {
        try {
            currentFolderUri = documentUri
            fileList.removeAllViews()
            val back = Button(this).apply { text = "BACK TO ALLOWED FOLDERS"; setOnClickListener { showAllowedFolders() } }
            fileList.addView(back)
            val children = mutableListOf<Pair<String, Uri>>()
            val treeChildren = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, DocumentsContract.getDocumentId(documentUri))
            contentResolver.query(treeChildren, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, DocumentsContract.Document.COLUMN_DISPLAY_NAME + " ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (c.moveToNext()) {
                    val name = c.getString(nameCol) ?: continue
                    val id = c.getString(idCol)
                    val mime = c.getString(mimeCol) ?: "*/*"
                    val isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR
                    if (isDir || isAllowedFile(name, mime)) {
                        children.add(name to DocumentsContract.buildDocumentUriUsingTree(treeUri, id))
                    }
                }
            }
            if (children.isEmpty()) {
                fileList.addView(TextView(this).apply { text = "No allowed files in this folder."; textSize = 18f; setPadding(12, 20, 12, 20) })
                return
            }
            children.forEach { (name, childUri) ->
                val button = Button(this).apply {
                    text = if (isDirectory(childUri)) "📁 $name" else "📄 $name"
                    setOnClickListener {
                        if (isDirectory(childUri)) browseFolder(treeUri, childUri) else openDocument(childUri, name)
                    }
                }
                fileList.addView(button)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Unable to read this folder", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isDirectory(uri: Uri): Boolean {
        return try {
            contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) == DocumentsContract.Document.MIME_TYPE_DIR else false
            } ?: false
        } catch (_: Exception) { false }
    }

    private fun isAllowedFile(name: String, mime: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext.isNotBlank() && allowedFileExtensions.contains(ext)
    }

    private fun openDocument(uri: Uri, name: String) {
        try {
            // APK files are never opened from the PisoTab client file browser.
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext == "apk" || !allowedFileExtensions.contains(ext)) {
                Toast.makeText(this, "This file type is blocked by Admin", Toast.LENGTH_LONG).show()
                return
            }

            val mime = contentResolver.getType(uri) ?: "*/*"
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            // Only an Admin-approved application may be used to open a file.
            val handlers = packageManager.queryIntentActivities(viewIntent, PackageManager.MATCH_DEFAULT_ONLY)
            val allowedHandler = handlers.firstOrNull {
                allowedPackages.contains(it.activityInfo.packageName) &&
                    it.activityInfo.packageName != packageName
            }

            if (allowedHandler == null) {
                Toast.makeText(this, "No Admin-approved app can open $name", Toast.LENGTH_LONG).show()
                return
            }

            val launch = packageManager.getLaunchIntentForPackage(allowedHandler.activityInfo.packageName)
            if (launch != null) {
                launch.action = Intent.ACTION_VIEW
                launch.setDataAndType(uri, mime)
                launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(launch)
            } else {
                Toast.makeText(this, "Approved app cannot be launched", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "No Admin-approved app is available to open $name", Toast.LENGTH_LONG).show()
        }
    }

    private fun showFileControlDialog() {
        if (allowedFolderUris.isEmpty()) {
            Toast.makeText(this, "Add an allowed folder first.", Toast.LENGTH_LONG).show()
        }
        val extensions = arrayOf("pdf", "jpg", "jpeg", "png", "gif", "mp4", "mp3", "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx")
        val checked = BooleanArray(extensions.size) { allowedFileExtensions.contains(extensions[it]) }
        AlertDialog.Builder(this)
            .setTitle("FILE ACCESS CONTROL")
            .setMultiChoiceItems(extensions, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setMessage("Only selected file types inside Admin-approved folders are shown in PisoTab Files. System file managers remain outside this app-level control without Device Owner/MDM.")
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE") { _, _ ->
                allowedFileExtensions = extensions.filterIndexed { i, _ -> checked[i] }.toSet()
                Toast.makeText(this, "Allowed file types saved", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("ADD FOLDER") { _, _ -> requestAllowedFolder() }
            .show()
    }

    private fun requestAllowedFolder() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            }
            startActivityForResult(intent, 901)
        } catch (_: Exception) {
            Toast.makeText(this, "Folder picker unavailable", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 901 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            allowedFolderUris = allowedFolderUris + uri.toString()
            Toast.makeText(this, "Folder added to PisoTab allowed files", Toast.LENGTH_SHORT).show()
            showFileControlDialog()
        }
    }

    private fun requestHomeLauncherRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (!roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
                        startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME), 700)
                    } else {
                        Toast.makeText(this, "PisoTab is already the Home Launcher", Toast.LENGTH_SHORT).show()
                    }
                    return
                }
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "Select PisoTab as Home app in Android Settings", Toast.LENGTH_LONG).show()
    }

    private fun goToHomeLauncher() {
        // Return to the Android Home/Launcher. If PisoTab is the default Home app,
        // Android will keep PisoTab as the Home surface (useful for kiosk mode).
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addCategory(Intent.CATEGORY_DEFAULT)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (_: Exception) {
            closeBrowser()
        }
    }

    private fun closeBrowser() {
        browserPanel.visibility = View.GONE
        filePanel.visibility = View.GONE
        mainPanel.visibility = View.VISIBLE
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 22)
        }
    }

    /**
     * Applies Android Lock Task only when PisoTab is actually provisioned as
     * the Device Owner. On ordinary devices this is a no-op.
     */
    private fun applyDeviceOwnerRestrictions() {
        if (!isDeviceOwner()) return

        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(this, PisoTabDeviceAdminReceiver::class.java)

        try {
            dpm.setLockTaskPackages(admin, arrayOf(packageName))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                if (am.lockTaskModeState == android.app.ActivityManager.LOCK_TASK_MODE_NONE) {
                    startLockTask()
                }
            }
        } catch (_: SecurityException) {
            // Normal app mode remains available if Device Owner is not provisioned.
        } catch (_: Exception) {
            // OEM-specific policy differences must not break the launcher UI.
        }
    }

    private fun applyVolumeLimit() {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val target = (max * maxVolumePercent / 100.0).toInt().coerceIn(0, max)
            if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) > target) {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            }
        } catch (_: Exception) { }
    }

    private fun applyKioskMode() {
        if (!kioskMode) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            return
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun isDeviceOwner(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isDeviceOwnerApp(packageName)
    }

    private fun isInLockTaskModeCompat(): Boolean {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return if (Build.VERSION.SDK_INT >= 23) dpm.isLockTaskPermitted(packageName) && (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).lockTaskModeState != android.app.ActivityManager.LOCK_TASK_MODE_NONE else false
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAccessBlockedIntent(intent)
    }

    private fun handleAccessBlockedIntent(intent: Intent?) {
        when (intent?.getStringExtra("ACCESS_BLOCKED")) {
            "APP_NOT_ALLOWED" -> Toast.makeText(this, "App blocked by PisoTab Admin whitelist", Toast.LENGTH_LONG).show()
            "SYSTEM_PATH_BLOCKED" -> Toast.makeText(this, "Android Settings / system controls are Admin-only", Toast.LENGTH_LONG).show()
            "SESSION_LOCKED" -> Toast.makeText(this, "Session expired. Insert a coin or unlock with Admin PIN.", Toast.LENGTH_LONG).show()
        }
    }

    private fun persistSessionState() {
        prefs.edit().putLong("session_seconds", secondsLeft).apply()
    }

    override fun onResume() {
        super.onResume()
        applyVolumeLimit()
        if (activeCustomerPackage != null) {
            activeCustomerPackage = null
            applyKioskMode()
        }
        renderAllowedApps()
    }

    private fun addCoin() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        sessionLocked = false
        coins++
        secondsLeft += minutesPerPeso * 60L
        applyRemoteLockUi()
        updateScreen()
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) { secondsLeft = ms / 1000L; updateScreen() }
            override fun onFinish() {
                secondsLeft = 0
                if (autoClearOnExpiry) {
                    clearCustomerSession()
                    if (resetCustomerAppsOnSessionEnd) clearCustomerAppData()
                } else {
                    coins = 0
                }
                closeBrowser()
                sessionLocked = true
                updateScreen()
                applyRemoteLockUi()
                Toast.makeText(this@MainActivity, "TIME EXPIRED - TABLET LOCKED", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun clearCustomerSession() {
        coins = 0
        timer?.cancel()
        try { webView.stopLoading() } catch (_: Exception) {}
        try { webView.clearHistory() } catch (_: Exception) {}
        try { webView.clearCache(true) } catch (_: Exception) {}
        try { webView.clearFormData() } catch (_: Exception) {}
        try { webView.clearSslPreferences() } catch (_: Exception) {}
        try { WebStorage.getInstance().deleteAllData() } catch (_: Exception) {}
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().removeSessionCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
        try { webView.loadUrl("about:blank") } catch (_: Exception) {}
        try { cacheDir.deleteRecursively() } catch (_: Exception) {}
        try { externalCacheDir?.deleteRecursively() } catch (_: Exception) {}
        try { filesDir.resolve("customer_session").deleteRecursively() } catch (_: Exception) {}
        try { getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.deleteRecursively() } catch (_: Exception) {}
        try { getSharedPreferences("customer_browser_session", MODE_PRIVATE).edit().clear().apply() } catch (_: Exception) {}
    }

    private fun clearCustomerAppData() {
        // App data clearing is intentionally disabled without Device Owner.
        // PisoTab clears its own browser/session data on expiry.
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        val value = String.format("%02d:%02d:%02d", h, m, s)
        txtTime.text = value
        txtBrowserTime.text = value
        txtCoins.text = "Coins: $coins"
        txtRate.text = "₱1 = $minutesPerPeso minutes"
        persistSessionState()
    }

    private fun connectEsp32() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: run { Toast.makeText(this, "Bluetooth not supported", Toast.LENGTH_SHORT).show(); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { requestBtPermission(); return }
        val target = btTargetName.trim()
        val devices = adapter.bondedDevices.filter { (it.name ?: "").contains(target, true) }
        if (devices.isEmpty()) { Toast.makeText(this, "Pair $target in Android Bluetooth settings first.", Toast.LENGTH_LONG).show(); return }
        connectDevice(devices.first())
    }

    private fun connectDevice(device: BluetoothDevice) {
        txtEsp32.text = "ESP32: CONNECTING..."
        thread {
            try {
                socket?.close()
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket!!.connect()
                runOnUiThread { txtEsp32.text = "ESP32: CONNECTED" }
                listenBluetooth(socket!!)
            } catch (_: Exception) {
                runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun listenBluetooth(s: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(s.inputStream))
            while (s.isConnected) {
                val line = reader.readLine() ?: break
                if (line.trim().equals("COIN1", true)) runOnUiThread { addCoin() }
            }
        } catch (_: Exception) {
            runOnUiThread { txtEsp32.text = "ESP32: NOT CONNECTED"; if (bluetoothAlarm) Toast.makeText(this, "BLUETOOTH DISCONNECTED", Toast.LENGTH_LONG).show() }
        }
    }

    private fun showUnlockDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Admin password"
        }
        AlertDialog.Builder(this)
            .setTitle("ADMIN UNLOCK")
            .setMessage("Enter Admin Password to unlock the expired session.")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK") { _, _ ->
                if (input.text.toString() == adminPassword) {
                    sessionLocked = false
                    remoteLocked = false
                    prefs.edit().putLong("admin_unlock_until", System.currentTimeMillis() + 10 * 60 * 1000L).apply()
                    applyRemoteLockUi()
                    Toast.makeText(this, "Session unlocked by admin", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Incorrect Admin password", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showPasswordDialog() {
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "Admin password" }
        AlertDialog.Builder(this).setTitle("ADMIN / STAFF LOGIN").setMessage("Enter Admin Password or Staff PIN").setView(input).setNegativeButton("CANCEL", null).setPositiveButton("OK") { _, _ ->
            val value = input.text.toString()
            if (value == adminPassword || value == staffPassword) {
                val isAdmin = value == adminPassword
                if (isAdmin) prefs.edit().putLong("admin_unlock_until", System.currentTimeMillis() + 10 * 60 * 1000L).apply()
                showSettingsDialog(isAdmin)
            }
            else Toast.makeText(this, "Incorrect Admin / Staff password!", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showSettingsDialog(isAdmin: Boolean) {
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 8)
        }

        fun addToggle(label: String, checked: Boolean, enabled: Boolean = true): CheckBox =
            CheckBox(this).also {
                it.text = label
                it.isChecked = checked
                it.isEnabled = enabled
                menu.addView(it)
            }

        val clientHeader = TextView(this).apply {
            text = "CLIENT CONFIGURATION"
            textSize = 16f
            setPadding(0, 8, 0, 4)
        }
        menu.addView(clientHeader)

        val clientNameInput = EditText(this).apply {
            hint = "Client Name"
            setText(clientName)
            isEnabled = isAdmin
        }
        menu.addView(clientNameInput)

        val clientIdInput = EditText(this).apply {
            hint = "Client ID"
            setText(clientId)
            isEnabled = isAdmin
        }
        menu.addView(clientIdInput)

        val coinMinutes = EditText(this).apply {
            hint = "Minutes per ₱1"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(minutesPerPeso.toString())
        }
        menu.addView(coinMinutes)

        val volumeLimit = EditText(this).apply {
            hint = "Maximum Music Volume % (0-100)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(maxVolumePercent.toString())
            isEnabled = isAdmin
        }
        menu.addView(volumeLimit)

        val password = EditText(this).apply {
            hint = if (isAdmin) "New Admin Password" else "New Staff PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        menu.addView(password)

        val kiosk = addToggle("Kiosk Mode", kioskMode, isAdmin)
        val launcher = addToggle("Default Launcher", defaultLauncher, isAdmin)
        val btAlarm = addToggle("Bluetooth Disconnect Alarm", bluetoothAlarm, isAdmin)
        val chAlarm = addToggle("Charger Disconnect Alarm", chargerAlarm, isAdmin)
        val whitelist = addToggle("Whitelist Apps", whitelistMode, isAdmin)
        val autoClear = addToggle("Auto-clear customer session when timer expires", autoClearOnExpiry, isAdmin)
        val resetApps = addToggle("Reset customer app data when session ends", resetCustomerAppsOnSessionEnd, isAdmin)

        val remoteToggle = addToggle("Remote Management", remoteControlEnabled, isAdmin)

        val remoteUrlInput = EditText(this).apply {
            hint = "Remote Control HTTPS URL (use {clientId})"
            setText(remoteControlUrl)
            isEnabled = isAdmin
        }
        menu.addView(remoteUrlInput)

        val remoteIntervalInput = EditText(this).apply {
            hint = "Remote Poll Seconds (10-300)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(remotePollSeconds.toString())
            isEnabled = isAdmin
        }
        menu.addView(remoteIntervalInput)

        val target = EditText(this).apply {
            hint = "Bluetooth Target Name"
            setText(btTargetName)
        }
        menu.addView(target)

        if (isAdmin) {
            menu.addView(Button(this).apply {
                text = "MANAGE ALLOWED APPS"
                setOnClickListener { showAllowedAppsDialog() }
            })
            menu.addView(Button(this).apply {
                text = "FILE ACCESS CONTROL"
                setOnClickListener { showFileControlDialog() }
            })
            menu.addView(Button(this).apply {
                text = "CLEAR REMOTE LOCK (LOCAL ADMIN)"
                setOnClickListener {
                    remoteLocked = false
                    remoteLockMessage = "This client is temporarily disabled by the administrator."
                    applyRemoteLockUi()
                    Toast.makeText(this@MainActivity, "Local remote lock cleared", Toast.LENGTH_SHORT).show()
                }
            })
        }

        // Keep the settings content scrollable while keeping SAVE/CANCEL
        // permanently visible at the bottom of the dialog.
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(menu)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 8)
            addView(scroll, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            ))
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }

        val cancelButton = Button(this).apply {
            text = "CANCEL"
            setOnClickListener { dialogRef?.dismiss() }
        }
        val saveButton = Button(this).apply {
            text = "SAVE"
            isAllCaps = true
        }

        buttons.addView(cancelButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        buttons.addView(saveButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        root.addView(buttons, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (isAdmin) "KIOSK & LAUNCHER CONTROL" else "COIN TIMER SETTINGS")
            .setMessage("Coin Timer / Device Settings")
            .setView(root)
            .create()

        dialogRef = dialog

        saveButton.setOnClickListener {
            val n = coinMinutes.text.toString().toIntOrNull()
            if (n == null || n <= 0) {
                coinMinutes.error = "Enter a number greater than 0"
                coinMinutes.requestFocus()
                return@setOnClickListener
            }

            minutesPerPeso = n
            if (isAdmin) {
                clientName = clientNameInput.text.toString().trim().ifEmpty { "Client 01" }
                clientId = clientIdInput.text.toString().trim().ifEmpty { "C001" }
            }
            val newPassword = password.text.toString().trim()
            if (newPassword.isNotEmpty()) {
                if (isAdmin) adminPassword = newPassword else staffPassword = newPassword
            }

            if (isAdmin) {
                kioskMode = kiosk.isChecked
                defaultLauncher = launcher.isChecked
                bluetoothAlarm = btAlarm.isChecked
                chargerAlarm = chAlarm.isChecked
                whitelistMode = whitelist.isChecked
                autoClearOnExpiry = autoClear.isChecked
                resetCustomerAppsOnSessionEnd = resetApps.isChecked
                maxVolumePercent = (volumeLimit.text.toString().toIntOrNull() ?: 50).coerceIn(0, 100)
                remoteControlEnabled = remoteToggle.isChecked
                remoteControlUrl = remoteUrlInput.text.toString().trim()
                remotePollSeconds = (remoteIntervalInput.text.toString().toIntOrNull() ?: 15).coerceIn(10, 300)
            }

            btTargetName = target.text.toString().trim().ifEmpty { "ESP32" }
            updateScreen()
            applyVolumeLimit()
            applyKioskMode()
            applyDeviceOwnerRestrictions()
            applyRemoteLockUi()
            startRemoteControl()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            dialogRef = null

            if (isAdmin && launcher.isChecked) {
                requestHomeLauncherRole()
            }
        }

        cancelButton.setOnClickListener {
            dialog.dismiss()
            dialogRef = null
        }

        dialog.setOnDismissListener { dialogRef = null }
        dialog.show()

        // Give the dialog a usable tablet width and ensure the custom button
        // row remains visible instead of being pushed below the screen.
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.90f).toInt(),
            (resources.displayMetrics.heightPixels * 0.88f).toInt()
        )
    }


    private fun getLaunchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    /**
     * Returns user-facing installed apps that have a launch intent. This is
     * intentionally broader than queryIntentActivities() alone so apps with
     * unusual launcher declarations can still be selected by the admin.
     */
    private fun getManagedApps(): List<Pair<String, String>> {
        val result = linkedMapOf<String, String>()
        val launcherApps = getLaunchableApps()
        launcherApps.forEach { info ->
            val pkg = info.activityInfo.packageName
            result[pkg] = info.loadLabel(packageManager).toString()
        }

        packageManager.getInstalledApplications(PackageManager.MATCH_ALL).forEach { app ->
            if (app.packageName == packageName) return@forEach
            val launch = packageManager.getLaunchIntentForPackage(app.packageName) ?: return@forEach
            val label = app.loadLabel(packageManager).toString()
            if (label.isNotBlank() && launch != null) result[app.packageName] = label
        }

        return result.entries
            .map { it.key to it.value }
            .sortedBy { it.second.lowercase() }
    }

    private fun showAllowedAppsDialog() {
        val apps = getManagedApps()
        if (apps.isEmpty()) {
            Toast.makeText(this, "No launchable installed apps found", Toast.LENGTH_LONG).show()
            return
        }

        val selected = allowedPackages.toMutableSet()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 8)
        }

        val help = TextView(this).apply {
            text = "Piliin ng Admin ang mga installed app na puwedeng buksan ng client. Hindi kasama ang PisoTab."
            textSize = 16f
            setPadding(0, 0, 0, 12)
        }
        container.addView(help)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(list)
        container.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        apps.forEach { (pkg, label) ->
            val row = CheckBox(this).apply {
                text = label
                textSize = 18f
                isChecked = pkg in selected
                setPadding(4, 10, 4, 10)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(pkg) else selected.remove(pkg)
                }
            }
            list.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("ALLOWED APPLICATIONS")
            .setView(container)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                allowedPackages = selected.toSet()
                whitelistMode = true
                renderAllowedApps()
                Toast.makeText(this, "Allowed apps saved: ${selected.size}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.92f).toInt(),
                (resources.displayMetrics.heightPixels * 0.82f).toInt()
            )
        }
        dialog.show()
    }

    private fun renderAllowedApps() {
        if (!::allowedAppsGrid.isInitialized) return

        allowedAppsGrid.removeAllViews()
        // Show every launchable installed app like a normal system launcher.
        // The admin whitelist still controls whether an app can actually be opened.
        val apps = getManagedApps().sortedBy { it.second.lowercase() }

        if (apps.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No launchable apps found."
                setTextColor(resources.getColor(R.color.white, theme))
                textSize = 13f
                gravity = android.view.Gravity.CENTER
                setPadding(8, 24, 8, 24)
            }
            allowedAppsGrid.addView(empty)
            return
        }

        val size = (resources.displayMetrics.density * 78f).toInt()
        val margin = (resources.displayMetrics.density * 4f).toInt()

        apps.forEach { (pkg, label) ->
            val icon = try {
                packageManager.getApplicationIcon(pkg)
            } catch (_: Exception) {
                null
            }

            val iconButton = Button(this).apply {
                contentDescription = "Open $label"
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setTextColor(resources.getColor(R.color.white, theme))
                text = label
                textSize = 10.5f
                isAllCaps = false
                gravity = android.view.Gravity.CENTER
                compoundDrawablePadding = (resources.displayMetrics.density * 2f).toInt()
                setPadding(3, 3, 3, 3)
                if (icon != null) {
                    icon.setBounds(0, 0, size - 18, size - 18)
                    setCompoundDrawables(null, icon, null, null)
                }
                setOnClickListener {
                    if (remoteLocked || sessionLocked || secondsLeft <= 0L) {
                        Toast.makeText(this@MainActivity, "Insert a coin first", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    if (pkg !in allowedPackages) {
                        Toast.makeText(this@MainActivity, "App not allowed by Admin", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    if (activeCustomerPackage != null) {
                        Toast.makeText(this@MainActivity, "Close the current app using Recent/Square first.", Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch == null) {
                        Toast.makeText(this@MainActivity, "$label is no longer installed", Toast.LENGTH_SHORT).show()
                        renderAllowedApps()
                        return@setOnClickListener
                    }
                    activeCustomerPackage = pkg
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }

            val params = GridLayout.LayoutParams().apply {
                width = size
                height = size
                setMargins(margin, margin, margin, margin)
            }
            allowedAppsGrid.addView(iconButton, params)
        }
    }

    private fun applyWhitelistPolicy() {
        // App-level whitelist is enforced when PisoTab opens customer apps.
        // System-wide suspension requires Device Owner and is intentionally disabled.
    }

    private fun showCustomerAppsDialog() {
        if (remoteLocked) { Toast.makeText(this, "CLIENT IS REMOTELY LOCKED", Toast.LENGTH_SHORT).show(); return }
        if (secondsLeft <= 0L) {
            Toast.makeText(this, "Insert a coin first", Toast.LENGTH_SHORT).show()
            return
        }
        val allowed = getLaunchableApps().filter { it.activityInfo.packageName in allowedPackages }
        if (allowed.isEmpty()) {
            Toast.makeText(this, "No allowed apps configured", Toast.LENGTH_SHORT).show()
            return
        }
        val names = allowed.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ALLOWED APPS")
            .setItems(names) { _, which ->
                try {
                    if (activeCustomerPackage != null) {
                        Toast.makeText(this, "Close the current app first using the square/Recent button, then return to PisoTab.", Toast.LENGTH_LONG).show()
                        return@setItems
                    }
                    val pkg = allowed[which].activityInfo.packageName
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch != null) {
                        activeCustomerPackage = pkg
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launch)
                    }
                } catch (_: Exception) {
                    activeCustomerPackage = null
                    Toast.makeText(this, "App could not be opened", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun applyRemoteLockUi() {
        val locked = remoteLocked || sessionLocked
        remoteLockOverlay.visibility = if (locked) View.VISIBLE else View.GONE
        txtRemoteLockMessage.text = if (sessionLocked && !remoteLocked) "TIME EXPIRED. Insert a new coin or unlock with Admin PIN." else remoteLockMessage
        txtRemoteLockClient.text = "Client: $clientId — $clientName"
        mainPanel.isEnabled = !locked
        browserPanel.isEnabled = !locked
        if (locked) {
            timer?.cancel()
            secondsLeft = 0L
            coins = 0
            browserPanel.visibility = View.GONE
            mainPanel.visibility = View.VISIBLE
            clearCustomerSession()
            if (resetCustomerAppsOnSessionEnd) clearCustomerAppData()
        }
    }

    private fun startRemoteControl() {
        remoteRunning = false
        remoteThread?.interrupt()
        if (!remoteControlEnabled || remoteControlUrl.isBlank()) return
        remoteRunning = true
        remoteThread = thread(isDaemon = true, name = "PisoTabRemoteControl") {
            while (remoteRunning) {
                pollRemoteCommand()
                try { Thread.sleep(remotePollSeconds.coerceIn(10, 300) * 1000L) } catch (_: InterruptedException) { break }
            }
        }
    }

    private fun pollRemoteCommand() {
        var conn: HttpURLConnection? = null
        try {
            val base = remoteControlUrl
            val separator = if (base.contains("?")) "&" else "?"
            val urlString = base.replace("{clientId}", Uri.encode(clientId)) +
                if (base.contains("{clientId}")) "" else "${separator}clientId=${Uri.encode(clientId)}&clientName=${Uri.encode(clientName)}"
            conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("X-PisoTab-Client-Id", clientId)
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val locked = json.optBoolean("locked", remoteLocked)
                val message = json.optString("message", remoteLockMessage)
                runOnUiThread {
                    remoteLockMessage = message
                    if (locked != remoteLocked) {
                        remoteLocked = locked
                        applyRemoteLockUi()
                        Toast.makeText(this, if (locked) "REMOTE LOCK ENABLED" else "REMOTE UNLOCK ENABLED", Toast.LENGTH_LONG).show()
                    } else {
                        applyRemoteLockUi()
                    }
                }
            }
        } catch (_: Exception) {
            // Fail closed: retain the last known lock state when the server is unreachable.
        } finally {
            conn?.disconnect()
        }
    }

    override fun onBackPressed() {
        if (browserPanel.visibility == View.VISIBLE) {
            if (webView.canGoBack()) webView.goBack() else closeBrowser()
        } else if (!kioskMode) {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        remoteRunning = false
        remoteThread?.interrupt()
        timer?.cancel()
        try { socket?.close() } catch (_: Exception) {}
        try { webView.destroy() } catch (_: Exception) {}
        super.onDestroy()
    }
}
