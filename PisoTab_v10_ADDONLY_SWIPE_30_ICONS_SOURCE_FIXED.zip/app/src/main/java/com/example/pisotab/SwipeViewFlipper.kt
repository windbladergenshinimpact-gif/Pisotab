package com.example.pisotab

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.ViewFlipper
import kotlin.math.abs

/**
 * v10 add-only launcher paging.
 * Intercepts only a clear horizontal swipe so child app buttons still receive normal taps.
 */
class SwipeViewFlipper @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewFlipper(context, attrs) {

    private var downX = 0f
    private var downY = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
                return false
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY

                if (!dragging &&
                    abs(dx) > 60f * resources.displayMetrics.density &&
                    abs(dx) > abs(dy) * 1.2f
                ) {
                    dragging = true
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
            }
        }

        return dragging
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX

                if (abs(dx) > 60f * resources.displayMetrics.density) {
                    if (dx < 0f && displayedChild < childCount - 1) {
                        showNext()
                    } else if (dx > 0f && displayedChild > 0) {
                        showPrevious()
                    }
                }

                dragging = false
                performClick()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
