package com.example.pisotab

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * PisoTab's Device Policy Controller component.
 *
 * Installing the APK does NOT make it Device Owner. Android must explicitly
 * provision this receiver as the Device Owner on a managed device. On devices
 * where that is not done, PisoTab continues to work as a normal application.
 */
class PisoTabDeviceAdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "PisoTab device management enabled", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(context, "PisoTab device management disabled", Toast.LENGTH_SHORT).show()
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)

        // The Activity performs the final Lock Task configuration when it is
        // opened. Keep this callback intentionally lightweight so provisioning
        // remains compatible with Android versions/OEM firmware that restrict
        // background activity launches.
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, PisoTabDeviceAdminReceiver::class.java)
        if (dpm.isDeviceOwnerApp(context.packageName)) {
            try {
                dpm.setLockTaskPackages(admin, arrayOf(context.packageName))
            } catch (_: SecurityException) { }
        }
    }
}
