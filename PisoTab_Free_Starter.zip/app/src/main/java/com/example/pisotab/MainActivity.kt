package com.example.pisotab

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var txtTime: TextView
    private lateinit var txtCoins: TextView
    private var coins = 0
    private var secondsLeft = 0L
    private var timer: CountDownTimer? = null

    // Change this: 1 peso = 10 minutes
    private val minutesPerPeso = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtTime = findViewById(R.id.txtTime)
        txtCoins = findViewById(R.id.txtCoins)

        findViewById<Button>(R.id.btnTestCoin).setOnClickListener {
            addCoin()
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            Toast.makeText(
                this,
                "Settings/password module will be added next.",
                Toast.LENGTH_SHORT
            ).show()
        }

        updateScreen()
    }

    private fun addCoin() {
        coins++
        secondsLeft += minutesPerPeso * 60L
        txtCoins.text = "Coins: $coins"
        startTimer()
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                secondsLeft = ms / 1000L
                updateScreen()
            }

            override fun onFinish() {
                secondsLeft = 0
                updateScreen()
                Toast.makeText(
                    this@MainActivity,
                    "TIME EXPIRED",
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun updateScreen() {
        val h = secondsLeft / 3600
        val m = (secondsLeft % 3600) / 60
        val s = secondsLeft % 60
        txtTime.text = String.format("%02d:%02d:%02d", h, m, s)
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
