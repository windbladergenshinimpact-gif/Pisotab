from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from urllib.parse import urlparse, parse_qs

STATE = {}

class Handler(BaseHTTPRequestHandler):
    def _send(self, data):
        raw = json.dumps(data).encode()
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        qs = parse_qs(urlparse(self.path).query)
        client_id = qs.get('clientId', ['C001'])[0]
        state = STATE.get(client_id, {'locked': False, 'message': 'Client enabled'})
        self._send(state)

    def log_message(self, fmt, *args):
        print(fmt % args)

if __name__ == '__main__':
    print('PisoTab demo remote server on http://0.0.0.0:8080')
    print('GET /?clientId=C001 returns current state')
    print('Edit STATE in this file or replace with your authenticated admin API.')
    HTTPServer(('0.0.0.0', 8080), Handler).serve_forever()
