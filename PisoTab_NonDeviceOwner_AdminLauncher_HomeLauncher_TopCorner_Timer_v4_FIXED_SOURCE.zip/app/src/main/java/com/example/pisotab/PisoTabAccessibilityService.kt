package com.example.pisotab

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * App-level guard for non-Device-Owner deployments.
 * It cannot provide system-level tamper-proof kiosk security, but it can
 * return the user to PisoTab when common Settings/launcher/installer paths
 * are opened while the admin session is not unlocked.
 */
class PisoTabAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("pisotab_settings", Context.MODE_PRIVATE) }
    private var lastRedirectAt = 0L
    private var lastPackage = ""

    private val guardedPackages = setOf(
        "com.android.settings",
        "com.google.android.settings",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.android.documentsui",
        "com.google.android.documentsui",
        "com.android.launcher3",
        "com.google.android.apps.nexuslauncher",
        "com.android.launcher",
        "com.android.intentresolver",
        "com.google.android.permissioncontroller"
    )

    private fun adminUnlocked(): Boolean {
        return prefs.getLong("admin_unlock_until", 0L) > System.currentTimeMillis()
    }

    private fun clientSessionActive(): Boolean {
        val seconds = prefs.getLong("session_seconds", 0L)
        return seconds > 0L
    }

    private fun allowedApps(): Set<String> {
        return prefs.getStringSet("allowed_packages", emptySet())?.toSet() ?: emptySet()
    }

    private fun isPisoTab(pkg: String): Boolean = pkg == packageName

    private fun isGuardedSystemPackage(pkg: String): Boolean = guardedPackages.contains(pkg)

    private fun redirect(reason: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRedirectAt < 700) return
        lastRedirectAt = now
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("ACCESS_BLOCKED", reason)
        }
        startActivity(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg.isBlank() || pkg == lastPackage && event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        lastPackage = pkg

        if (adminUnlocked() || isPisoTab(pkg)) return

        // If the client session has expired, any attempt to leave PisoTab is
        // sent back to the lock screen.
        if (!clientSessionActive()) {
            redirect("SESSION_LOCKED")
            return
        }

        // Block common system management paths for the client.
        if (isGuardedSystemPackage(pkg)) {
            redirect("SYSTEM_PATH_BLOCKED")
            return
        }

        // Block apps that the admin did not whitelist.
        val allowed = allowedApps()
        if (allowed.isNotEmpty() && !allowed.contains(pkg)) {
            // Do not fight the system during boot/setup; only redirect when
            // the service actually observes a foreground package.
            redirect("APP_NOT_ALLOWED")
        }
    }

    override fun onInterrupt() = Unit
}
